﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Staff
{
    class SalaryManage
    {
        public int EmployeeId
        {
            get; set;
        }
        public string Month { get; set; }
        public string Amount { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {

            string mydata = "";
            mydata += EmployeeId.ToString() + "\n";
            mydata += Month.ToString() + "\n";
            mydata += Amount.ToString() + "\n";
            mydata += Date.ToString() + "\n";
            mydata += Description.ToString() + "\n";

            return mydata;
        }

        internal static void Add(SalaryManage sal)
        {
            throw new NotImplementedException();
        }
    }
}
