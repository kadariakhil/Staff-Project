﻿namespace Staff
{
    partial class StaffReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffReports));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.cbdes = new System.Windows.Forms.ComboBox();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtadd = new System.Windows.Forms.TextBox();
            this.cbgen = new System.Windows.Forms.ComboBox();
            this.dtdob = new System.Windows.Forms.DateTimePicker();
            this.txtcon = new System.Windows.Forms.TextBox();
            this.StaffDGV = new System.Windows.Forms.DataGridView();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnbtm = new System.Windows.Forms.Button();
            this.btnclr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 132);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Designation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 195);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 279);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(551, 68);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Dob";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(551, 141);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(551, 211);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Contact";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(290, 58);
            this.txtname.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(199, 27);
            this.txtname.TabIndex = 7;
            // 
            // cbdes
            // 
            this.cbdes.FormattingEnabled = true;
            this.cbdes.Items.AddRange(new object[] {
            "Associate Enginner",
            "Test Engineer",
            "Software Developer"});
            this.cbdes.Location = new System.Drawing.Point(290, 129);
            this.cbdes.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.cbdes.Name = "cbdes";
            this.cbdes.Size = new System.Drawing.Size(199, 28);
            this.cbdes.TabIndex = 8;
            // 
            // txtmail
            // 
            this.txtmail.Location = new System.Drawing.Point(290, 195);
            this.txtmail.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(199, 27);
            this.txtmail.TabIndex = 9;
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(290, 279);
            this.txtadd.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtadd.Multiline = true;
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(718, 63);
            this.txtadd.TabIndex = 10;
            // 
            // cbgen
            // 
            this.cbgen.FormattingEnabled = true;
            this.cbgen.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.cbgen.Location = new System.Drawing.Point(676, 141);
            this.cbgen.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.cbgen.Name = "cbgen";
            this.cbgen.Size = new System.Drawing.Size(330, 28);
            this.cbgen.TabIndex = 11;
            // 
            // dtdob
            // 
            this.dtdob.Location = new System.Drawing.Point(676, 62);
            this.dtdob.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.dtdob.Name = "dtdob";
            this.dtdob.Size = new System.Drawing.Size(330, 27);
            this.dtdob.TabIndex = 12;
            // 
            // txtcon
            // 
            this.txtcon.Location = new System.Drawing.Point(676, 206);
            this.txtcon.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtcon.Name = "txtcon";
            this.txtcon.Size = new System.Drawing.Size(330, 27);
            this.txtcon.TabIndex = 13;
            // 
            // StaffDGV
            // 
            this.StaffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StaffDGV.Location = new System.Drawing.Point(166, 445);
            this.StaffDGV.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.StaffDGV.Name = "StaffDGV";
            this.StaffDGV.Size = new System.Drawing.Size(919, 191);
            this.StaffDGV.TabIndex = 14;
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Black;
            this.btnadd.Location = new System.Drawing.Point(96, 369);
            this.btnadd.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(125, 35);
            this.btnadd.TabIndex = 15;
            this.btnadd.Text = "ADD";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click_1);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.Black;
            this.btnupdate.Location = new System.Drawing.Point(314, 369);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(125, 35);
            this.btnupdate.TabIndex = 16;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click_1);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Black;
            this.btndelete.Location = new System.Drawing.Point(589, 369);
            this.btndelete.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(125, 35);
            this.btndelete.TabIndex = 17;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click_1);
            // 
            // btnbtm
            // 
            this.btnbtm.BackColor = System.Drawing.Color.Black;
            this.btnbtm.Location = new System.Drawing.Point(765, 369);
            this.btnbtm.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnbtm.Name = "btnbtm";
            this.btnbtm.Size = new System.Drawing.Size(164, 35);
            this.btnbtm.TabIndex = 18;
            this.btnbtm.Text = "BACKTOMAIN";
            this.btnbtm.UseVisualStyleBackColor = false;
            this.btnbtm.Click += new System.EventHandler(this.btnbtm_Click_1);
            // 
            // btnclr
            // 
            this.btnclr.BackColor = System.Drawing.Color.Black;
            this.btnclr.Location = new System.Drawing.Point(974, 369);
            this.btnclr.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnclr.Name = "btnclr";
            this.btnclr.Size = new System.Drawing.Size(125, 35);
            this.btnclr.TabIndex = 19;
            this.btnclr.Text = "CLEAR";
            this.btnclr.UseVisualStyleBackColor = false;
            this.btnclr.Click += new System.EventHandler(this.btnclr_Click);
            // 
            // StaffReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1334, 692);
            this.Controls.Add(this.btnclr);
            this.Controls.Add(this.btnbtm);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.StaffDGV);
            this.Controls.Add(this.txtcon);
            this.Controls.Add(this.dtdob);
            this.Controls.Add(this.cbgen);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.cbdes);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Aqua;
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "StaffReports";
            this.Text = "StaffReports";
            this.Load += new System.EventHandler(this.StaffReports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox cbdes;
        private System.Windows.Forms.TextBox txtmail;
        private System.Windows.Forms.TextBox txtadd;
        private System.Windows.Forms.ComboBox cbgen;
        private System.Windows.Forms.DateTimePicker dtdob;
        private System.Windows.Forms.TextBox txtcon;
        private System.Windows.Forms.DataGridView StaffDGV;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnbtm;
        private System.Windows.Forms.Button btnclr;
    }
}