﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Staff
{
    public partial class SalaryManagement : Form
    {
        SqlConnection conn;
        public SalaryManagement()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void SalaryManagement_Load(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SalaryManage sm = new SalaryManage();
            sm.EmployeeId = int.Parse(txtid.Value.ToString());
            sm.Month = txtmonth.Text;
            sm.Amount = txtamount.Text;
            sm.Date = dtpay.Value.ToString();
            sm.Description = txtdesc.Text;

            MessageBox.Show(sm.ToString());


            string sql = String.Format("insert into SalaryManagement values({0},'{1}',{2},'{3}','{4}')", sm.EmployeeId, sm.Month, sm.Amount, sm.Date, sm.Description);

            MessageBox.Show(sql);
            List<SalaryManage> saldetails = new List<SalaryManage>();
            try
            {

                string query = "select * from SalaryManagement";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("successful insertion");

                SqlCommand cmd1 = new SqlCommand(query, conn);
                SqlDataReader reader = cmd1.ExecuteReader();
                while (reader.Read())
                {
                    SalaryManage sal = new SalaryManage();

                    sal.EmployeeId = int.Parse(reader[0].ToString());
                    sal.Month = reader[1].ToString();
                    sal.Amount = reader[2].ToString();
                    sal.Date = reader[3].ToString();
                    sal.Description = reader[4].ToString();
                    saldetails.Add(sal);
                }
                dgalldata.DataSource = saldetails;
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show("data cannot be inserted \n" + ob.Message);
            }
            clearall();
        }
        private void clearall()
        {

            txtmonth.Text = "";
            txtamount.Text = "";
            txtdesc.Text = "";

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("update SalaryManagement set Month='" + txtmonth.Text + "',Amount='" + txtamount.Text + "',Date='" + dtpay.Text + "',description='" + txtdesc.Text + "' where EmployeeId='" + txtid.Text + "'", conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                conn.Close();
                populate();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void populate()
        {

            conn.Open();

            string query = "select * from SalaryManagement";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dgalldata.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {

                MessageBox.Show("Select the valid EmployeeId");

            }
            else
            {

                try
                {
                    conn.Open();
                    string query = "delete from SalaryManagement where EmployeeId='" + txtid.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record deleted Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);

                }
            }
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void btnbacktomain_Click(object sender, EventArgs e)
        {
            Dashboardnew ob = new Dashboardnew();
            ob.Show();
            this.Hide();
        }
    }
}
    

    

