﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Staff
{
    public partial class Dashboardnew : Form
    {
        public Dashboardnew()
        {
            InitializeComponent();
        }

        private void staffReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
           StaffReports ob = new StaffReports();
            ob.Show();
            this.Hide();
        }

        private void salaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalaryManagement ob = new SalaryManagement();
            ob.Show();

            this.Hide();
        }

        private void benefitReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BenifitsManagements ob = new BenifitsManagements();
        
         ob.Show();
            this.Hide();
        }

        private void Dashboardnew_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
