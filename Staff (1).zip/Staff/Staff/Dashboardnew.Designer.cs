﻿namespace Staff
{
    partial class Dashboardnew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboardnew));
            this.addstaffdetails = new System.Windows.Forms.MenuStrip();
            this.staffdetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salarymanagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.benefitsManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.benefitReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addstaffdetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // addstaffdetails
            // 
            this.addstaffdetails.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.addstaffdetails.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.staffdetailsToolStripMenuItem,
            this.salarymanagementToolStripMenuItem,
            this.benefitsManagementToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.addstaffdetails.Location = new System.Drawing.Point(0, 0);
            this.addstaffdetails.Name = "addstaffdetails";
            this.addstaffdetails.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.addstaffdetails.Size = new System.Drawing.Size(1067, 36);
            this.addstaffdetails.TabIndex = 1;
            this.addstaffdetails.Text = "Staff management";
            // 
            // staffdetailsToolStripMenuItem
            // 
            this.staffdetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.staffReportsToolStripMenuItem});
            this.staffdetailsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffdetailsToolStripMenuItem.Name = "staffdetailsToolStripMenuItem";
            this.staffdetailsToolStripMenuItem.Size = new System.Drawing.Size(120, 32);
            this.staffdetailsToolStripMenuItem.Text = "Staffdetails";
            // 
            // staffReportsToolStripMenuItem
            // 
            this.staffReportsToolStripMenuItem.Name = "staffReportsToolStripMenuItem";
            this.staffReportsToolStripMenuItem.Size = new System.Drawing.Size(216, 32);
            this.staffReportsToolStripMenuItem.Text = "StaffReports";
            this.staffReportsToolStripMenuItem.Click += new System.EventHandler(this.staffReportsToolStripMenuItem_Click);
            // 
            // salarymanagementToolStripMenuItem
            // 
            this.salarymanagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salaryReportToolStripMenuItem});
            this.salarymanagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salarymanagementToolStripMenuItem.Name = "salarymanagementToolStripMenuItem";
            this.salarymanagementToolStripMenuItem.Size = new System.Drawing.Size(190, 32);
            this.salarymanagementToolStripMenuItem.Text = "salaryManagement";
            // 
            // salaryReportToolStripMenuItem
            // 
            this.salaryReportToolStripMenuItem.Name = "salaryReportToolStripMenuItem";
            this.salaryReportToolStripMenuItem.Size = new System.Drawing.Size(202, 32);
            this.salaryReportToolStripMenuItem.Text = "SalaryReport";
            this.salaryReportToolStripMenuItem.Click += new System.EventHandler(this.salaryReportToolStripMenuItem_Click);
            // 
            // benefitsManagementToolStripMenuItem
            // 
            this.benefitsManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.benefitReportToolStripMenuItem});
            this.benefitsManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.benefitsManagementToolStripMenuItem.Name = "benefitsManagementToolStripMenuItem";
            this.benefitsManagementToolStripMenuItem.Size = new System.Drawing.Size(199, 32);
            this.benefitsManagementToolStripMenuItem.Text = "Benefitmanagement";
            // 
            // benefitReportToolStripMenuItem
            // 
            this.benefitReportToolStripMenuItem.Name = "benefitReportToolStripMenuItem";
            this.benefitReportToolStripMenuItem.Size = new System.Drawing.Size(209, 32);
            this.benefitReportToolStripMenuItem.Text = "BenefitReport";
            this.benefitReportToolStripMenuItem.Click += new System.EventHandler(this.benefitReportToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(55, 32);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Dashboardnew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.addstaffdetails);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dashboardnew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboardnew";
            this.Load += new System.EventHandler(this.Dashboardnew_Load);
            this.addstaffdetails.ResumeLayout(false);
            this.addstaffdetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip addstaffdetails;
        private System.Windows.Forms.ToolStripMenuItem staffdetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salarymanagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benefitsManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benefitReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}